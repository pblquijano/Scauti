@extends('layouts.master')
@section('css')

@stop
@section('content')
<div class=" no-pad-bot fullstate teal darken-1">
	<div class="container fullstate vertical-centered-text">
		<div class="row center">
			<img src="img/logo.svg" style="width:50%;margin: 0 auto 5px auto;">
			<br>
			<a href="" class="waves-effect waves-light btn-large"><i class="material-icons right">airplay</i>Iniciar</a>
		</div>
	</div>
</div>	
	

@stop
@section('scripts')

@stop